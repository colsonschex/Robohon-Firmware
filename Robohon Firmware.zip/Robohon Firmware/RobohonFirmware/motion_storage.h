#pragma once
#include <Arduino.h>
#include <vector>

#define NUM_SERVOS 12   // matches your servoNames list

// One frame of motion
struct Frame {
    uint16_t transition;        // milliseconds
    float angles[NUM_SERVOS];   // angles in degrees (float)
};

// One full motion
struct Motion {
    uint8_t frameCount = 0;
    std::vector<Frame> frames;

    bool loop = false;
    uint8_t loopStart = 0;
};

// Initialize filesystem (LittleFS)
bool motionStorageInit();

// Save a Motion into a slot
bool motionStorageSave(uint8_t slot, const Motion& motion);

// Load a Motion from a slot
bool motionStorageLoad(uint8_t slot, Motion& outMotion);

// List all slots that contain motions
std::vector<uint8_t> motionStorageList();

// Delete a slot
bool motionStorageDelete(uint8_t slot);
