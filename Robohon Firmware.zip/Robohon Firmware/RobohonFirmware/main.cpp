#include <Arduino.h>
#include "config.h"
#include "servo_bus.h"
#include "motion_player.h"
#include "motion_storage.h"
#include "command_handler.h"
#include "wifi_ws.h"
#include "ble_uart.h"
#include "servo_bridge.h"

// =====================================================
// SETUP
// =====================================================
void setup() {
    Serial.begin(115200);
    delay(300);
    Serial.println();
    Serial.println("RoBoHoN ESP32-C3 firmware booting...");

    // Initialize servo buses
    servoBusInit();

    // Send home frames to all buses
    Serial.println("Sending home frames...");
    servoSendHome(BUS_HEAD_ID);
    servoSendHome(BUS_LEG_ID);
    servoSendHome(BUS_SHOULDER_ID);

    // Release all servos
    Serial.println("Releasing servos...");
    servoRelease();

    // Initialize storage
    if (!motionStorageInit()) {
        Serial.println("LittleFS init failed");
    }

    // Initialize motion player + command handler
    motionPlayerInit();
    commandHandlerInit();

    // Initialize BLE UART (Connect App)
    bleUartInit();

    // Initialize WiFi + WebSocket server (Motion Editor)
    Serial.println("Starting WiFi + WebSocket...");
    wifiWsInit();

    Serial.println("Setup complete.");
}

// =====================================================
// LOOP
// =====================================================
void loop() {
    // -------------------------------------------------
    // 1. Manual override ONLY when bridge is OFF
    // -------------------------------------------------
    if (!servoBridgeActive()) {
        if (Serial.available()) {
            String cmd = Serial.readStringUntil('\n');
            cmd.trim();
            if (cmd.equalsIgnoreCase("bridge on")) {
                servoBridgeEnable();
                Serial.println("[BRIDGE] ENABLED (manual)");
            }
            else if (cmd.equalsIgnoreCase("bridge off")) {
                servoBridgeDisable();
                Serial.println("[BRIDGE] DISABLED (manual)");
            }
        }
    }

    // -------------------------------------------------
    // 2. Always update transports and motion player
    // -------------------------------------------------
    wifiWsUpdate();         // keep WebSocket alive
    bleUartUpdate();        // keep BLE alive
    motionPlayerUpdate();   // run motions (always, even in bridge mode)

    // -------------------------------------------------
    // 3. If bridge mode is active, forward raw frames
    // -------------------------------------------------
    if (servoBridgeActive()) {
        servoBridgePoll();
    }
}