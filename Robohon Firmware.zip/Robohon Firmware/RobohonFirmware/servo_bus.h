#pragma once
#include <Arduino.h>

// ============================================================
// Bus IDs
// ============================================================
enum BusID {
    BUS_LEG_ID = 0,
    BUS_HEAD_ID = 1,
    BUS_SHOULDER_ID = 2
};

// ============================================================
// Public API (servo bus only)
// ============================================================
void servoBusInit();
int16_t servoClamp(uint8_t sid, BusID bus, int16_t val);

void servoSendHome(BusID bus);
void servoRelease(BusID bus);
void servoRelease();

void servoWriteFrame(BusID bus, const int16_t* positions);
void servoWriteFrame(const int16_t* positions);

void servoSendRawFrame(BusID bus, uint8_t* buf, size_t len);