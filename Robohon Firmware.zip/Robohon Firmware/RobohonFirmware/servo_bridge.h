#pragma once
#include <stdint.h>
#include <stddef.h>
#include "servo_bus.h"

// Enable/disable bridge mode
void servoBridgeEnable();
void servoBridgeDisable();
bool servoBridgeActive();

// Push a single raw byte from ANY transport (USB, BLE, WiFi)
void servoBridgePushByte(uint8_t b);

// Poll the bridge (called every loop)
void servoBridgePoll();
