#pragma once
#include <stdint.h>

// ============================================================
// Hardware Configuration for ESP32-C3 Super Mini
// ============================================================
#define STATUS_LED_PIN 10
#define STATUS_LED_COUNT 1

// ============================================================
// Wi‑Fi Credentials (Option 1 — Hard‑coded)
// ============================================================
#define WIFI_SSID       "MyOptimum 0ac540"
#define WIFI_PASSWORD   "81-lavender-4485"

// UART
#define SERVO_UART_NUM      1
#define SERVO_UART_BAUD     115200
#define SERVO_UART_TX_PIN   7
#define SERVO_UART_RX_PIN   6
#define SERVO_DIR_PIN       10

// Servo Layout
#define NUM_SERVOS  12
#define NUM_BUSES   3

// Bus indices (match servo_bus.h enum)
#define BUS_LEG         0
#define BUS_HEAD        1
#define BUS_SHOULDER    2

// Timing
#define BUS_SWITCH_DELAY_US  50
#define FRAME_GAP_US         200

// Protocol
#define SERVO_FLAG_MOVE 0x40
#define SERVO_FLAG_FREE 0xFF
#define SERVO_FRAME_LEN 30

// ============================================================
// Home Positions (raw)
// ============================================================

// LEG
#define HOME_LEFT_HIP        1439
#define HOME_LEFT_FOOT      -2330
#define HOME_LEFT_ANKLE       -36
#define HOME_RIGHT_HIP       1565
#define HOME_RIGHT_FOOT     -1256

// SHOULDER
#define HOME_LEFT_SHOULDER    2839
#define HOME_RIGHT_SHOULDER  -2330

// HEAD / ELBOW
#define HOME_NECK_TURN         239
#define HOME_HEAD_NOD        -2530
#define HOME_HEAD_TILT        2270
#define HOME_LEFT_ELBOW       1565
#define HOME_RIGHT_ELBOW     -1256

// ============================================================
// Mechanical Limits (raw)
// ============================================================

// LEG
#define LIMIT_LEFT_HIP_MIN    -18235
#define LIMIT_LEFT_HIP_MAX     21439
#define LIMIT_LEFT_FOOT_MIN   -20530
#define LIMIT_LEFT_FOOT_MAX    12670
#define LIMIT_LEFT_ANKLE_MIN   -5636
#define LIMIT_LEFT_ANKLE_MAX    1764
#define LIMIT_RIGHT_HIP_MIN   -20835
#define LIMIT_RIGHT_HIP_MAX    18965
#define LIMIT_RIGHT_FOOT_MIN  -15256
#define LIMIT_RIGHT_FOOT_MAX   16944

// SHOULDER
#define LIMIT_LEFT_SHOULDER_MIN   -24161
#define LIMIT_LEFT_SHOULDER_MAX    2439
#define LIMIT_RIGHT_SHOULDER_MIN  -24330
#define LIMIT_RIGHT_SHOULDER_MAX   24070

// HEAD / ELBOW
#define LIMIT_NECK_TURN_MIN      -15361
#define LIMIT_NECK_TURN_MAX       14839
#define LIMIT_HEAD_NOD_MIN        -2330
#define LIMIT_HEAD_NOD_MAX          470
#define LIMIT_HEAD_TILT_MIN       -2130
#define LIMIT_HEAD_TILT_MAX        7670
#define LIMIT_LEFT_ELBOW_MIN      -1835
#define LIMIT_LEFT_ELBOW_MAX      15965
#define LIMIT_RIGHT_ELBOW_MIN    -16256
#define LIMIT_RIGHT_ELBOW_MAX      1744

// ============================================================
// Servo Mapping (extern — defined in config.cpp)
// ============================================================
extern const uint8_t SERVO_BUS_MAP[NUM_SERVOS];
extern const uint8_t SERVO_ID_MAP[NUM_SERVOS];
extern const char*   servoNames[NUM_SERVOS];
