#include "servo_bridge.h"
#include "servo_bus.h"
#include "ble_uart.h"
#include "wifi_ws.h"
#include <Arduino.h>

// ============================================================
// Bridge mode state
// ============================================================
static bool g_bridgeMode = false;

// ============================================================
// Unified 30-byte frame buffer
// ============================================================
static uint8_t frameBuf[30];
static int frameIdx = 0;

// ============================================================
// Enable / Disable
// ============================================================
void servoBridgeEnable() {
    g_bridgeMode = true;
    frameIdx = 0;
    Serial.println("[BRIDGE] ENABLED");
}

void servoBridgeDisable() {
    g_bridgeMode = false;
    frameIdx = 0;
    Serial.println("[BRIDGE] DISABLED");
}

bool servoBridgeActive() {
    return g_bridgeMode;
}

// ============================================================
// Checksum validator (bytes 6..28)
// ============================================================
static bool frameValid(const uint8_t* f) {
    if (f[0] != 0x77 || f[1] != 0x80) return false;
    uint32_t sum = 0;
    for (int i = 6; i < 29; i++) sum += f[i];
    uint8_t expected = (uint8_t)((256 - (sum & 0xFF)) & 0xFF);
    return f[29] == expected;
}

// ============================================================
// Push a byte from ANY transport
// ============================================================
void servoBridgePushByte(uint8_t b) {
    if (!g_bridgeMode) return;

    frameBuf[frameIdx++] = b;

    if (frameIdx == 30) {
        frameIdx = 0;

        if (!frameValid(frameBuf)) {
            // silently drop invalid frame
            return;
        }

        // Bus ID is stored in byte[2] by the JS editor (routing byte)
        // sendRawFrame will zero it before transmission
        BusID bus = (BusID)frameBuf[2];
        if (bus > BUS_SHOULDER_ID) bus = BUS_LEG_ID;

        servoSendRawFrame(bus, frameBuf, 30);
    }
}

// ============================================================
// Polling: drain USB, BLE, WiFi
// ============================================================
void servoBridgePoll() {
    if (!g_bridgeMode) return;

    // USB
    while (Serial.available()) {
        servoBridgePushByte(Serial.read());
    }

    // BLE
    while (bleUartAvailable()) {
        servoBridgePushByte(bleUartRead());
    }

    // WiFi WebSocket
    uint8_t b;
    while (wifiWsReadByte(&b)) {
        servoBridgePushByte(b);
    }
}