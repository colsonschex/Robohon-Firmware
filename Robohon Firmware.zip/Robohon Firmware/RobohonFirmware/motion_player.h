#pragma once
#include <Arduino.h>
#include "motion_storage.h"
#include "servo_bus.h"

// Initialize player state
void motionPlayerInit();

// Load a motion into the player
void motionPlayerLoad(const Motion& motion);

// Start playback
void motionPlayerPlay();

// Stop playback
void motionPlayerStop();

// Check if playing
bool motionPlayerIsPlaying();

// Update playback (call frequently)
void motionPlayerUpdate();

// Convert normalized angle (-1..+1) → raw servo position
int16_t angleToPosition(float norm, uint8_t sid, BusID bus);

// Build a 5‑slot frame for a specific bus
void buildBusFrame(BusID bus, const float* allAngles, int16_t out[5]);
