// Required by Arduino IDE.
// Actual firmware entry point is in main.cpp.
