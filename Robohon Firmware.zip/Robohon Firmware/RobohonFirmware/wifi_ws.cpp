#include "wifi_ws.h"
#include "servo_bridge.h"
#include "command_handler.h"
#include "config.h"

#include <WiFi.h>
#include <ESPAsyncWebServer.h>
#include <Adafruit_NeoPixel.h>

// ============================================================
// WS2812 Status LED (GPIO 10 on ESP32‑C3 Zero)
// ============================================================
static Adafruit_NeoPixel statusLed(STATUS_LED_COUNT, STATUS_LED_PIN, NEO_GRB + NEO_KHZ800);

static unsigned long ledTimer = 0;
static bool ledState = false;
static int wsClientCount = 0;

// ============================================================
// WebSocket server
// ============================================================
static AsyncWebServer server(80);
static AsyncWebSocket ws("/ws");

// ============================================================
// RX ring buffer for binary data (WiFi → servo bridge)
// Written from AsyncWebSocket callback (async task)
// Read from loop() via wifiWsReadByte()
// Uses atomic operations to avoid race corruption
// ============================================================
static const size_t RX_BUF_SIZE = 2048;
static uint8_t rxBuf[RX_BUF_SIZE];
static volatile size_t rxHead = 0;
static volatile size_t rxTail = 0;

static inline bool rxBufferPush(uint8_t b) {
    size_t head = __atomic_load_n(&rxHead, __ATOMIC_ACQUIRE);
    size_t next = (head + 1) % RX_BUF_SIZE;
    if (next == __atomic_load_n(&rxTail, __ATOMIC_ACQUIRE)) return false; // overflow
    rxBuf[head] = b;
    __atomic_store_n(&rxHead, next, __ATOMIC_RELEASE);
    return true;
}

bool wifiWsReadByte(uint8_t* out) {
    size_t tail = __atomic_load_n(&rxTail, __ATOMIC_ACQUIRE);
    if (tail == __atomic_load_n(&rxHead, __ATOMIC_ACQUIRE)) return false; // empty
    *out = rxBuf[tail];
    __atomic_store_n(&rxTail, (tail + 1) % RX_BUF_SIZE, __ATOMIC_RELEASE);
    return true;
}

// ============================================================
// WiFi + WebSocket Init
// ============================================================
void wifiWsInit() {

    // Init WS2812 LED
    statusLed.begin();
    statusLed.setBrightness(50);
    statusLed.clear();
    statusLed.show();

    WiFi.mode(WIFI_STA);
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

    Serial.print("Connecting to WiFi");

    // Fast blink while connecting
    while (WiFi.status() != WL_CONNECTED) {
        unsigned long now = millis();
        if (now - ledTimer >= 100) {
            ledTimer = now;
            ledState = !ledState;
            if (ledState)
                statusLed.setPixelColor(0, statusLed.Color(255, 255, 0)); // yellow
            else
                statusLed.clear();
            statusLed.show();
        }

        delay(50);
        Serial.print(".");
    }

    Serial.println("\nWiFi connected.");
    Serial.print("IP: ");
    Serial.println(WiFi.localIP().toString());

    // --------------------------------------------------------
    // WebSocket event handler
    // --------------------------------------------------------
    ws.onEvent([](AsyncWebSocket *server,
                  AsyncWebSocketClient *client,
                  AwsEventType type,
                  void *arg,
                  uint8_t *data,
                  size_t len)
    {
        if (type == WS_EVT_CONNECT) {
            wsClientCount++;
            servoBridgeEnable();
            return;
        }

        if (type == WS_EVT_DISCONNECT) {
            if (wsClientCount > 0) wsClientCount--;
            if (wsClientCount == 0) servoBridgeDisable();
            return;
        }

        if (type != WS_EVT_DATA) return;

        AwsFrameInfo *info = (AwsFrameInfo*)arg;

        // ----------------------------------------------------
        // BINARY FRAME → push bytes into RX ring buffer
        // ----------------------------------------------------
        if (info->opcode == WS_BINARY) {
            for (size_t i = 0; i < len; i++) {
                rxBufferPush(data[i]);
            }
            return;
        }

        // ----------------------------------------------------
        // TEXT FRAME → JSON command
        // ----------------------------------------------------
        if (info->opcode == WS_TEXT) {
            String line = String((char*)data).substring(0, len);
            commandHandlerHandleLine(line);
            return;
        }
    });

    server.addHandler(&ws);
    server.begin();
}

// ============================================================
// LED + WebSocket update
// ============================================================
void wifiWsUpdate() {
    unsigned long now = millis();

    // WiFi disconnected → LED OFF
    if (WiFi.status() != WL_CONNECTED) {
        statusLed.clear();
        statusLed.show();
        return;
    }

    // Solid green if WS client connected
    if (wsClientCount > 0) {
        statusLed.setPixelColor(0, statusLed.Color(0, 255, 0)); // green
        statusLed.show();
        return;
    }

    // Slow blink (connected but idle)
    if (now - ledTimer >= 500) {
        ledTimer = now;
        ledState = !ledState;

        if (ledState)
            statusLed.setPixelColor(0, statusLed.Color(0, 0, 255)); // blue
        else
            statusLed.clear();

        statusLed.show();
    }
}

// ============================================================
// Send binary data to ALL connected WS clients
// ============================================================
bool wifiWsSend(const uint8_t *data, size_t len) {
    ws.binaryAll(data, len);
    return true;
}